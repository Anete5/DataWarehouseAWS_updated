import configparser

# CONFIG
config = configparser.ConfigParser()
config.read('dwh.cfg')

IAM_ROLE = config.get("IAM_ROLE", "ARN")
LOG_DATA = config.get("S3", "LOG_DATA")
LOG_PATH = config.get("S3", "LOG_JSONPATH")
SONG_DATA = config.get("S3", "SONG_DATA")

# DROP TABLES

staging_events_table_drop = "DROP TABLE IF EXISTS staging_events"
staging_songs_table_drop = "DROP TABLE IF EXISTS staging_songs"
song_plays_table_drop = "DROP TABLE IF EXISTS song_plays"
users_table_drop = "DROP TABLE IF EXISTS users"
songs_table_drop = "DROP TABLE IF EXISTS songs"
artists_table_drop = "DROP TABLE IF EXISTS artists"
time_table_drop = "DROP TABLE IF EXISTS time"

# CREATE TABLES

staging_events_table_create = ("""

CREATE TABLE IF NOT EXISTS staging_events (
    song_play_id        INT IDENTITY(0,1)   PRIMARY KEY,
    artist              VARCHAR(MAX),
    auth                VARCHAR, 
    first_name          VARCHAR,
    gender              VARCHAR,   
    item_in_session     INT,
    last_name           VARCHAR,
    length              FLOAT,
    level               VARCHAR, 
    location            VARCHAR(MAX),
    method              VARCHAR,
    page                VARCHAR,
    registration        BIGINT,
    session_id          INT,
    song                VARCHAR(MAX),
    status              INT,
    ts                  BIGINT,
    user_agent          VARCHAR,
    user_id             INT
);
""")

staging_songs_table_create = ("""

CREATE TABLE IF NOT EXISTS staging_songs (
    song_id             VARCHAR     PRIMARY KEY,
    num_songs           INT,
    title               VARCHAR(MAX),
    year                INT,
    duration            FLOAT,
    artist_id           VARCHAR,
    artist_name         VARCHAR(MAX),
    artist_latitude     FLOAT,
    artist_longitude    FLOAT,
    artist_location     VARCHAR(MAX)
);
""")

song_plays_table_create = ("""

CREATE TABLE IF NOT EXISTS song_plays (
    song_play_id    INT         IDENTITY(0,1)   PRIMARY KEY,
    start_time      TIMESTAMP   NOT NULL, 
    user_id         INT         NOT NULL,
    level           VARCHAR,
    song_id         VARCHAR,
    artist_id       VARCHAR,
    session_id      INT,
    location        VARCHAR,
    user_agent      VARCHAR        
);
""")

users_table_create = ("""

CREATE TABLE IF NOT EXISTS users (
    user_id         INT     NOT NULL    PRIMARY KEY,
    first_name      VARCHAR,
    last_name       VARCHAR,
    gender          VARCHAR,
    level           VARCHAR
);
""")

songs_table_create = ("""

CREATE TABLE IF NOT EXISTS songs (
    song_id         VARCHAR     PRIMARY KEY,
    title           VARCHAR(MAX),
    artist_id       VARCHAR,
    year            INT,
    duration        FLOAT      
);    
""")

artists_table_create = ("""

CREATE TABLE IF NOT EXISTS artists (
    artist_id       VARCHAR         PRIMARY KEY,
    name            VARCHAR(MAX)    NOT NULL,
    location        VARCHAR,
    latitude        FLOAT,
    longitude       FLOAT
    );
""")

time_table_create = ("""

CREATE TABLE IF NOT EXISTS time (
    start_time  TIMESTAMP    NOT NULL    PRIMARY KEY,
    hour        INT,
    day         INT,
    week        INT,
    month       INT,
    year        INT,
    weekday     INT
    );
""")

# STAGING TABLES

staging_events_copy = ("""
copy staging_events from {} 
credentials 'aws_iam_role={}'
compupdate off region 'us-west-2'
FORMAT AS json {}
BLANKSASNULL EMPTYASNULL;
""").format(LOG_DATA, IAM_ROLE, LOG_PATH)

staging_songs_copy = ("""
copy staging_songs from {} 
credentials 'aws_iam_role={}'
compupdate off region 'us-west-2'
FORMAT AS json 'auto'
BLANKSASNULL EMPTYASNULL;
""").format(SONG_DATA, IAM_ROLE)

# FINAL TABLES

song_plays_table_insert = ("""

INSERT INTO song_plays (start_time, user_id, level, song_id, artist_id, session_id, location, user_agent)
SELECT 
    DISTINCT TO_TIMESTAMP(e.ts/1000)
    e.user_id,
    e.level,
    s.song_id,
    s.artist_id,
    e.session_id,
    e.location,
    e.user_agent
FROM staging_events e
JOIN staging_songs s 
    ON e.song = s.title 
    AND e.artist = s.artist_name
WHERE e.user_id IS NOT NULL
AND e.page = 'NextSong';
""")

users_table_insert = ("""

INSERT INTO users (user_id, first_name, last_name, gender, level)
SELECT 
    DISTINCT user_id, 
    first_name, 
    last_name, 
    gender, 
    level
FROM staging_events
WHERE user_id IS NOT NULL;
""")

songs_table_insert = ("""

INSERT INTO songs (song_id, title, artist_id, year, duration)
SELECT 
    DISTINCT song_id, 
    title, 
    artist_id, 
    year, 
    duration
FROM staging_songs;
""")

artists_table_insert = ("""

INSERT INTO artists (artist_id, name, location, latitude, longitude)
SELECT 
    DISTINCT artist_id, 
    artist_name AS name, 
    artist_location AS location, 
    artist_latitude AS latitude, 
    artist_longitude AS longitude
FROM staging_songs;
""")

time_table_insert = ("""

INSERT INTO time (start_time, hour, day, week, month, year, weekday)
SELECT 
    DISTINCT TO_TIMESTAMP(ts/1000) AS start_time, 
    EXTRACT(hour from TO_TIMESTAMP(ts/1000)) AS hour,
    EXTRACT(day from TO_TIMESTAMP(ts/1000)) AS day, 
    EXTRACT(week from TO_TIMESTAMP(ts/1000)) AS week,
    EXTRACT(month from TO_TIMESTAMP(ts/1000)) AS month, 
    EXTRACT(year from TO_TIMESTAMP(ts/1000)) AS year,
    EXTRACT(dow from TO_TIMESTAMP(ts/1000)) AS weekday
FROM staging_events;    
""")

# QUERY LISTS

create_table_queries = [staging_events_table_create, staging_songs_table_create, users_table_create,
                        artists_table_create, songs_table_create, time_table_create, song_plays_table_create]
drop_table_queries = [staging_events_table_drop, staging_songs_table_drop, users_table_drop, artists_table_drop,
                      songs_table_drop, time_table_drop, song_plays_table_drop]
copy_table_queries = [staging_events_copy, staging_songs_copy]
insert_table_queries = [song_plays_table_insert, users_table_insert, songs_table_insert, artists_table_insert,
                        time_table_insert]
