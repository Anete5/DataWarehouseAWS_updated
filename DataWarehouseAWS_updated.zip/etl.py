import configparser
import psycopg2
from sql_queries import copy_table_queries, insert_table_queries


def load_staging_tables(cur, conn):
    """Loads data from the buckets into the staging tables"""
    for query in copy_table_queries:
        try:
            cur.execute(query)
            conn.commit()
        except IOError as e:
            print('Error')
            continue


def insert_tables(cur, conn):
    """Inserts the data from the staging tables into analytical tables"""
    for query in insert_table_queries:
        cur.execute(query)
        conn.commit()


def main():
    """
    Creates a connection to the cluster;
    loads the data from the buckets into the staging tables;
    inserts the data from the staging tables into analytical tables
    """

    config = configparser.ConfigParser()
    config.read('dwh.cfg')

    conn = psycopg2.connect("host={} dbname={} user={} password={} port={}".format(*config['CLUSTER'].values()))
    cur = conn.cursor()

    load_staging_tables(cur, conn)
    insert_tables(cur, conn)

    conn.close()


if __name__ == "__main__":
    main()
