# Project: Data Warehouse

## About the project

This project is created for a startup called *Sparkify*. Its new music streaming app has grown their user base and song database so they want to move their processes and data onto the cloud. Their data resides in S3, in a directory of JSON logs on user activity on the app, as well as a directory with JSON metadata on the songs in their app.

To help *Sparkify* with moving to the cloud, I was brought to the project. The main project activities included building an ETL pipeline that extracts their data from S3, stages them in Redshift, and transforms data into a set of dimensional tables for their analytics team to continue finding insights into what songs their users are listening to.

To complete the project, I used PyCharm and JupyterLab for writing SQL, Python and interacting with AWS services as well as an AWS account for administrative and testing activities.

## Datasets

*Sparkify* provided me with two datasets - Songs and Logs.

Songs dataset includes all the metadata about a song and an artist. Below is an example of one of the JSON files:

**TRAAABD128F429CF47.json**

`{"num_songs": 1, "artist_id": "ARMJAGH1187FB546F3", "artist_latitude": 35.14968, "artist_longitude": -90.04892, "artist_location": "Memphis, TN", "artist_name": "The Box Tops", "song_id": "SOCIWDW12A8C13D406", "title": "Soul Deep", "duration": 148.03546, "year": 1969}`

Logs dataset includes all the data about user activity on the app. Below is an example of one of the JSON files:

**2018-11-01-events.json**

`{"artist":null,"auth":"Logged In","firstName":"Walter","gender":"M","itemInSession":0,"lastName":"Frye","length":null,"level":"free","location":"San Francisco-Oakland-Hayward, CA","method":"GET","page":"Home","registration":1540919166796.0,"sessionId":38,"song":null,"status":200,"ts":1541105830796,"userAgent":"\"Mozilla\/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/36.0.1985.143 Safari\/537.36\"","userId":"39"}`

Both datasets can be found in S3 storage. Below are examples of the filepaths:

**s3://udacity-dend/song_data**
**s3://udacity-dend/log_data**
**s3://udacity-dend/log_json_path.json**

## Database schema

The database schema that I needed to create consists of **one fact table** and **four dimension tables**.

The fact table called *song_plays* includes the following columns:

**song_plays table**

- songplay_id
- start_time
- user_id
- level
- song_id
- artist_id
- session_id
- location
- user_agent

The dimension tables called *artists*, *songs*, *users*, *time* include the following columns:

**artists table**

- artist_id
- name
- location
- latitude
- longitude

**songs table**

- song_id
- title
- artist_id
- year
- duration

**users table**

- user_id
- first_name
- last_name
- gender
- level

**time table**

- start_time
- hour
- day
- week
- month
- year
- weekday

# Project's template files

To implement specific project activities as well as assist me while working, I needed additional files. These files are the following:

1. **Work_test.ipynb**  - for testing purposes as well as interacting with AWS.

2. **create_tables.py** - for performing table drops and creates.

3. **etl.py** - for loading data from S3 into staging tables on Redshift and then processing that data into the analytics tables on Redshift.

5. **sql_queries.py**  - for writing SQL queries that are imported into the previous py files above.

6. **README.md**  - for providing discussion on this project.


# Project's steps

The project consists of several steps that are listed below.

**Create Table Schemas**

1. Design schemas for your fact and dimension tables
2. Write a SQL CREATE statement for each of these tables in sql_queries.py
3. Complete the logic in create_tables.py to connect to the database and create these tables
4. Write SQL DROP statements to drop tables in the beginning of create_tables.py if the tables already exist.
5. Launch a redshift cluster and create an IAM role that has read access to S3.
6. Add redshift database and IAM role info to dwh.cfg.
7. Test by running create_tables.py and checking the table schemas in the redshift database.

**Build ETL pipeline**

1. Implement the logic in etl.py to load data from S3 to staging tables on Redshift.
2. Implement the logic in etl.py to load data from staging tables to analytics tables on Redshift.
3. Test by running etl.py after running create_tables.py and running the analytic test queries on the Redshift database.
4. Delete the redshift cluster when finished.